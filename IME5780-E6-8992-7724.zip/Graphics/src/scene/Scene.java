package scene;

import elements.AmbientLight;
import elements.Camera;
import elements.LightSource;
import geometries.*;
import Primitives.*;

import java.util.LinkedList;
import java.util.List;

public class Scene {
   String _name;
   Color _background;
   AmbientLight _ambientLight;
   Geometries _geometries;
   Camera _camera;
   Double _distance;
   List<LightSource> _lights;

    /**Constructor
     * @param _name
     */
    public Scene(String _name) {
        this._name = _name;
        _geometries=new Geometries();
        _lights=new LinkedList<LightSource>();
    }


    /**_name getter
     * @return _name
     */
    public String get_name() {
        return _name;
    }

    /**_background getter
     * @return _background
     */
    public Color get_background() {
        return _background;
    }

    /**ambient light getter
     * @return _ambientlight
     */
    public AmbientLight get_ambientLight() {
        return _ambientLight;
    }

    /**geometires getter
     * @return _geometries
     */
    public Geometries get_geometries() {
        return _geometries;
    }

    /**camera getter
     * @return _camera
     */
    public Camera get_camera() {
        return _camera;
    }

    /**distance getter
     * @return _distance
     */
    public Double get_distance() {
        return _distance;
    }

    /**lights getter
     * @return _lights
     */
    public List<LightSource> get_lights() {
        return _lights;
    }

    //Set functions

    /**backgrouns setter
     * @param _background
     */
    public void set_background(Color _background) {
        this._background = _background;
    }

    /**ambient light setter
     * @param _ambientLight
     */
    public void set_ambientLight(AmbientLight _ambientLight) {
        this._ambientLight = _ambientLight;
    }

    /**camera setter
     * @param _camera
     */
    public void set_camera(Camera _camera) {
        this._camera = _camera;
    }

    /**distance setter
     * @param _distance
     */
    public void set_distance(Double _distance) {
        this._distance = _distance;
    }


    /**Adds a shape to the list of geometries.
     * @param geometries
     */
    public void addGeometries(Intersectable...geometries)
        {
            _geometries.add(geometries);
        }

    /**Adds a light to the list of light sources
     * @param Lights
     */
        public void addLights(LightSource...Lights)
        {
        for(LightSource l:Lights){
            _lights.add(l);
        }
        }

}
