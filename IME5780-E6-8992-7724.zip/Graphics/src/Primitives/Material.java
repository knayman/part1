package Primitives;

public class Material {
    double _kD;
    double _kS;
    double _nShininess;

    /**Constructor
     * @param _kD
     * @param _kS
     * @param _nShininess
     */
    public Material(double _kD, double _kS, double _nShininess) {
        this._kD = _kD;
        this._kS = _kS;
        this._nShininess = _nShininess;
    }

    /**kD getter
     * @return _kD
     */
    public double get_kD() {
        return _kD;
    }

    /**kS getter
     * @return _kS
     */
    public double get_kS() {
        return _kS;
    }

    /**nShininess getter
     * @return _nShininess
     */
    public double get_nShininess() {
        return _nShininess;
    }
}
