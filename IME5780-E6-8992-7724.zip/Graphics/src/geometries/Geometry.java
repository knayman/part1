package geometries;

import Primitives.Color;
import Primitives.Material;
import Primitives.Point3D;
import Primitives.Vector;

import java.awt.*;

public abstract class Geometry implements Intersectable
{
    protected Primitives.Color _emission;
    protected Material _material;
    public abstract Vector getNormal(Point3D _p);

    /**get function for _emission
     * @return _emission
     */
    public Primitives.Color get_emission() {
        return _emission;
    }

    /**get function for _material
     * @return _material
     */
    public Material get_material() {
        return _material;
    }

    /**Constructor
     * @param _emission
     * @param _material
     */
    public Geometry(Color _emission, Material _material) {
        this._emission = _emission;
        this._material = _material;
    }

    /**Constructor
     * @param _emission
     */
    public Geometry(Primitives.Color _emission) {
        this._emission = _emission;
        this._material=new Material(0,0,0);
    }

    /**
     * Default constructor
     */
    public Geometry() {
        _emission=Primitives.Color.BLACK;
        this._material=new Material(0,0,0);
    }
}

