package geometries;
import Primitives.*;

import java.util.List;
import java.util.Objects;

public interface Intersectable
{
    List<GeoPoint> findIntersections(Ray ray);

    /**
     * Helper class in order to connect between a point and the geometry it's on.
     */
    public static class GeoPoint {
        public Geometry geometry;
        public Point3D point;

        /**Constructor
         * @param geometry
         * @param point
         */
        public GeoPoint(Geometry geometry, Point3D point) {
            this.geometry = geometry;
            this.point = point;
        }

        /**Returns if the points are equal as well as the geometries.
         * @param o
         * @return
         */
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            GeoPoint geoPoint = (GeoPoint) o;
            return geometry.equals(geoPoint.geometry) &&
                    point.equals(geoPoint.point);
        }

    }

}
