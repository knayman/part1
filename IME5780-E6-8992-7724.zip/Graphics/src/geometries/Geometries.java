package geometries;

import Primitives.Point3D;
import Primitives.Ray;

import java.util.ArrayList;
import java.util.List;

public class Geometries implements Intersectable{

    List<Intersectable> lst;

    /**Constructor
     * We chose an array list because it is easier for iteration.
     */
    public Geometries(Intersectable...geometries)
    {
        if(lst==null)
            this.lst = new ArrayList<Intersectable>();
        else
            for (Intersectable g:geometries) {
                lst.add(g);

            }
    }

    /**adds geometries to list
     * @param geometries
     */
    public void add(Intersectable... geometries) {
        for (Intersectable g : geometries) {
            lst.add(g);
        }
    }

    /**Finds intersection points with geometries.
     * @param ray
     * @return
     */
    @Override
    public List<GeoPoint> findIntersections(Ray ray) {
        List<GeoPoint> intersections=new ArrayList<GeoPoint>();
        List<GeoPoint> tmp=new ArrayList<GeoPoint>();
        for (Intersectable g: lst) {
            tmp=g.findIntersections(ray);
               if(tmp!=null)
                   intersections.addAll(g.findIntersections(ray));
        }
        return intersections;
    }
}
