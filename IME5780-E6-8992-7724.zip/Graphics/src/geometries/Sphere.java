package geometries;

import Primitives.*;
import Primitives.Color;

import java.awt.*;
import java.util.List;



public class Sphere extends RadialGeometry
{
    private Point3D _p;

    /**Constructor
     * @param _emission
     * @param _material
     * @param radius
     * @param _p
     */
    public Sphere(Color _emission, Material _material, double radius, Point3D _p) {
        super(_emission, _material, radius);
        this._p = _p;
    }

    /**Constructor
     * @param _emission
     * @param radius
     * @param _p
     */
    public Sphere(Color _emission, double radius, Point3D _p) {
        super(_emission, radius);
        this._p = _p;
    }

    /**Constructor
     * @param radius
     * @param _p
     */
    public Sphere(double radius, Point3D _p) {
        super(radius);
        this._p = _p;
    }

    /**Returns normal to the point received.
     * @return vector
     */
    public Vector getNormal(Point3D point)
    {
        Vector orthogonal = new Vector(point.subtract(_p));
        return orthogonal.normalized();
    }

    /**
     * @param ray
     * @return Sphere intersection points
     */
    @Override
    public List<GeoPoint> findIntersections(Ray ray) {

        Point3D p0 = ray.get_point();
        Vector v = ray.get_vec();
        Vector u;
        try {
            u = _p.subtract(p0);   // p0 == _center
        } catch (IllegalArgumentException e) {
            Point3D p=ray.getPoint(getRadius());
            Geometry g=this;
            GeoPoint gp=new GeoPoint(g,p);
            return List.of(gp);
        }
        double tm = Util.alignZero(v.dotProduct(u));
        double dSquared = (tm == 0) ? u.lengthSquared() : u.lengthSquared() - tm * tm;
        double thSquared = Util.alignZero(getRadius()* getRadius()- dSquared);

        if (thSquared <= 0) return null;

        double th = Util.alignZero(Math.sqrt(thSquared));
        if (th == 0) return null;

        double t1 = Util.alignZero(tm - th);
        double t2 = Util.alignZero(tm + th);
        if (t1 <= 0 && t2 <= 0) return null;
        if (t1 > 0 && t2 > 0) {
            Point3D p1 = ray.getPoint(t1);
            Point3D p2 = ray.getPoint(t2);
            Geometry g = this;
            GeoPoint gp1 = new GeoPoint(g, p1);
            GeoPoint gp2 = new GeoPoint(g, p2);
            return List.of(gp1, gp2); //P1 , P2
        }
        if (t1 > 0)
        {
            Point3D p1 = ray.getPoint(t1);
            Geometry g = this;
            GeoPoint gp1 = new GeoPoint(g, p1);
            return List.of(gp1); //P1
        }
        else
        {
            Point3D p2 = ray.getPoint(t2);
            Geometry g = this;
            GeoPoint gp2 = new GeoPoint(g, p2);
            return List.of( gp2); //P2
        }
    }
    }

