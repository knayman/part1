package geometries;

import Primitives.Color;
import Primitives.Material;

import java.awt.*;

abstract public class RadialGeometry extends Geometry {
   private double radius;

    /**Constructor
     * @param _emission
     * @param _material
     * @param radius
     */
    public RadialGeometry(Color _emission, Material _material, double radius) {
        super(_emission, _material);
        this.radius = radius;
    }

    /**Constructor
     * @param _emission
     * @param radius
     */
    public RadialGeometry(Color _emission, double radius) {
        super(_emission);
        this.radius = radius;
    }

    /**Constructor
     * @param radius Double
     */
    public RadialGeometry(double radius) {

        this.radius = radius;
    }

    /**Get function
     * @return radius
     */
    public double getRadius() {
        return radius;
    }

    /**toString
     * @return string
     */
    @Override
    public String toString() {
        return "RadialGeometry{" +
                "radius=" + radius +
                '}';
    }


}
