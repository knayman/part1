package elements;

import Primitives.Color;
import Primitives.Point3D;
import Primitives.Vector;

public class PointLight extends Light implements LightSource{

    protected Point3D _position;
    protected double _kC;
    protected double _kL;
    protected double _kQ;

    /**Constructor
     * @param _intensity
     * @param _position
     * @param _kC
     * @param _kL
     * @param _kQ
     */
    public PointLight(Color _intensity, Point3D _position, double _kC, double _kL, double _kQ) {
        super(_intensity);
        this._position = _position;
        this._kC = _kC;
        this._kL = _kL;
        this._kQ = _kQ;
    }

    @Override
    public Color getIntensity(Point3D p) {
        double _distance=p.distance(_position);
        return _intensity.scale(1/(_kC+(_kL*_distance)+(_kQ*_distance*_distance)));
    }

    @Override
    public Vector getL(Point3D p) {
        return p.subtract(_position).normalize();
    }
}
