package elements;

import Primitives.Color;
import Primitives.Point3D;
import Primitives.Vector;

/**
 * Light interface-all light sources will implement methods
 */
public interface LightSource {
    Color getIntensity(Point3D p);
    Vector getL(Point3D p);

}
