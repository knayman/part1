package elements;

import Primitives.Color;
import Primitives.Point3D;
import Primitives.Vector;

import static java.lang.Math.max;

public class SpotLight extends PointLight{
    private Vector _direction;

    /**Constructor
     * @param _intensity
     * @param _position
     * @param _kC
     * @param _kL
     * @param _kQ
     * @param _direction
     */
    public SpotLight(Color _intensity, Point3D _position, double _kC, double _kL, double _kQ, Vector _direction) {
        super(_intensity, _position, _kC, _kL, _kQ);
        this._direction = _direction.normalize();
    }

    public Color getIntensity(Point3D p)
    {
        double _distance=p.distance(_position);
        double m=max(0,_direction.dotProduct(super.getL(p)));
        return _intensity.scale(m/(_kC+_kL*_distance+_kQ*_distance*_distance));

    }
}
