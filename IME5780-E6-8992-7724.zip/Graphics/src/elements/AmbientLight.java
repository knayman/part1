package elements;
import Primitives.*;
import Primitives.Color;

public class AmbientLight extends Light{
    Primitives.Color Ia;
    Double Ka;

    /**Constructor
     * @param ia
     * @param ka
     */
    public AmbientLight(Color ia, Double ka) {
        super(ia.scale(ka));
        Ia = ia;
        Ka = ka;
    }

}
