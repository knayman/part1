package elements;

import Primitives.Color;
import Primitives.Point3D;
import Primitives.Vector;

public class DirectionalLight extends Light implements LightSource  {

    private Vector _direction;

    /**Constructor
     * @param _intensity
     * @param _direction
     */
    public DirectionalLight(Color _intensity, Vector _direction) {
        super(_intensity);
        this._direction = _direction;
    }


    @Override
    public Color getIntensity(Point3D p) {
        return _intensity;
    }

    @Override
    public Vector getL(Point3D p) {
        return _direction.normalize();
    }
}
