package elements;

import Primitives.Color;
import Primitives.Point3D;

/**
 * Abstract class defining light-all lights will extend this class.
 */
abstract class Light
{
    protected Color _intensity;

    /**Constructor
     * @param _intensity
     */
    public Light(Color _intensity) {
        this._intensity = _intensity;
    }

    /**Getter for _intensity
     * @return
     */
    public Color get_intensity() {
        return _intensity;
    }
}
