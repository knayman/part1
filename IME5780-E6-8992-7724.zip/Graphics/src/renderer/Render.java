package renderer;

import Primitives.Color;
import Primitives.Point3D;
import Primitives.Ray;
import Primitives.Vector;
import scene.Scene;

import java.util.*;
import geometries.*;
import elements.*;
import geometries.Intersectable.GeoPoint;
import java.lang.Math;
public class Render {
    private ImageWriter _imageWriter;
    private Scene _scene;

    /**Constructor
     * @param _imageWriter
     * @param _scene
     */
    public Render(ImageWriter _imageWriter, Scene _scene) {
        this._imageWriter = _imageWriter;
        this._scene = _scene;
    }

// ***************** Getters ********************** //

    public ImageWriter get_imageWriter() {
        return _imageWriter;
    }

    public Scene get_scene() {
        return _scene;
    }

    /**
     *Creates rays through pixels and colors the pixel according to the intersection points.
     */
    public void renderImage() {
        Camera camera = _scene.get_camera();
        Intersectable geometries = _scene.get_geometries();
        java.awt.Color background = _scene.get_background().getColor();
        int nX = _imageWriter.getNx();
        int nY=_imageWriter.getNy();
        double distance=_scene.get_distance();
        double width=_imageWriter.getWidth();
        double height=_imageWriter.getHeight();
        Ray ray;
        List<GeoPoint> intersectionPoints=new ArrayList<GeoPoint>();
        for(int i=0;i<_imageWriter.getNx();i++) // i is pixel row number and j is pixel in the row number
            for(int j=0;j<_imageWriter.getNy();j++) {
                ray = camera.constructRayThroughPixel(nX, nY, j, i, distance, width, height);
                intersectionPoints = geometries.findIntersections(ray);
                if (intersectionPoints.size() == 0)
                    _imageWriter.writePixel(j, i, background);
                else {
                    GeoPoint closestPoint = getClosestPoint(intersectionPoints);
                    _imageWriter.writePixel(j, i, calcColor(closestPoint).getColor());
                }
            }
    }

    /**Calculates the closest intersection point to camera.
     * @param points
     * @return
     */
   private GeoPoint getClosestPoint(List<GeoPoint> points)
   {
     double distance=Double.MAX_VALUE;
     Point3D p0=_scene.get_camera().getPoint();
     GeoPoint minDistancePoint=null;
     for(GeoPoint Geopoint: points)
         if(p0.distance(Geopoint.point)<distance) {
             minDistancePoint = new GeoPoint(Geopoint.geometry,Geopoint.point);
             distance = p0.distance(Geopoint.point);
         }
     return minDistancePoint;
   }


    /**Calculates the color in given point.
     * @param point
     * @return
     */
    private Color calcColor(GeoPoint point) {
       Color ambientLight=_scene.get_ambientLight().get_intensity();
       Color emmissionLLight=point.geometry.get_emission();
       Color diffuseLight=new Color(0,0,0);
       Color specularLight=new Color(0,0,0);
       Vector n=point.geometry.getNormal(point.point).normalize();
       Vector v=(point.point).subtract(_scene.get_camera().getPoint()).normalize();
       for(LightSource l:_scene.get_lights())
       {
           if(Math.signum(n.dotProduct(l.getL(point.point)))==Math.signum(n.dotProduct(v))) {
               diffuseLight = diffuseLight.add(calcDiff(point, l));
               specularLight = specularLight.add(calcSpec(point, l));
           }
       }
       return new Color(ambientLight.add(emmissionLLight,diffuseLight,specularLight));
    }

    /**Calculates diffuse light
     * @param point
     * @param l
     * @return
     */
    public Color calcDiff(GeoPoint point,LightSource l)
    {
        Color inten=l.getIntensity(point.point);
        double kd=point.geometry.get_material().get_kD();
        double dotPro=(point.geometry.getNormal(point.point)).normalize().dotProduct(l.getL(point.point));
        return inten.scale(Math.abs(kd*dotPro));
    }

    /**Calculates specular light
     * @param point
     * @param l
     * @return
     */
    public Color calcSpec(GeoPoint point,LightSource l)
    {
        double ks=point.geometry.get_material().get_kS();
        Vector v=(point.point).subtract(_scene.get_camera().getPoint()).normalize();
        Vector d=l.getL(point.point);
        Vector n=point.geometry.getNormal(point.point).normalize();
        Vector r=d.subtract(n.scale(2*d.dotProduct(n)));
        double dotPro=v.scale(-1).dotProduct(r);
        return l.getIntensity(point.point).scale((Math.pow(Math.max(dotPro,0),point.geometry.get_material().get_nShininess())*ks));
    }

    /**Prints the grid
     * @param interval
     * @param color
     */
    public void printGrid(int interval, java.awt.Color color)
    {
        for(int i=0; i<_imageWriter.getWidth(); i++)
            for(int j=0; j<_imageWriter.getHeight(); j++) {
                if (i % interval == 0 || j % interval == 0)
                    _imageWriter.writePixel(i, j, color);
            }
    }
}
